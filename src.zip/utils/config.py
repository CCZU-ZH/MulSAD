import json
import os


class Config(object):
    """Base class for experimental setting/configuration."""

    def __init__(self, settings=None):
        # Default settings dictionary
        self.settings = {
            "dataset_name": "activatesonar",
            "net_name": "mnist_LeNet",
            "xp_path": "D:\\fuxian\\Deep-SAD-PyTorch-master\\result",
            "data_path": "D:\\fuxian\\HST\\data",
            "load_config": None,
            "load_model": None,
            "eta": 1.0,
            "ratio_known_normal": 0.0,
            "ratio_known_outlier": 0.0,
            "ratio_pollution": 0.0,
            "device": "cuda",
            "seed": 1015,
            "optimizer_name": "adam",
            "lr": 0.001,
            "n_epochs": 100,
            "lr_milestone": [0],
            "batch_size": 64,
            "weight_decay": 1e-6,
            "pretrain": True,
            "ae_optimizer_name": "adam",
            "ae_lr": 0.001,
            "ae_n_epochs": 100,
            "ae_lr_milestone": [0],
            "ae_batch_size": 64,
            "ae_weight_decay": 1e-6,
            "num_threads": 0,
            "n_jobs_dataloader": 0,
            "normal_class": 0,
            "known_outlier_class": 1,
            "n_known_outlier_classes": 0
        }

        # If external settings are provided, update the default settings
        if settings:
            self.settings.update(settings)

    def load_config(self, import_json=None):
        """Load settings dict from import_json (path/filename.json) JSON-file."""
        if import_json is None:
            print("No config file path provided.")
            return

        if not os.path.exists(import_json):
            print(f"Config file {import_json} not found.")
            return

        with open(import_json, 'r') as fp:
            settings = json.load(fp)

        # Update settings with the loaded config
        self.settings.update(settings)
        print(f"Settings loaded from {import_json}")

    def save_config(self, export_json=None):
        """Save settings dict to export_json (path/filename.json) JSON-file."""
        if export_json is None:
            print("No export file path provided.")
            return

        with open(export_json, 'w') as fp:
            json.dump(self.settings, fp, indent=4)
        print(f"Settings saved to {export_json}")
