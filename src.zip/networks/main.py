from .mlp import CNN_Autoencoder,CNN_Encoder

def build_network():
    """Builds the neural network."""
    net = CNN_Encoder()
    return net

def build_autoencoder():
    """Builds the corresponding autoencoder network."""

    ae_net = CNN_Autoencoder()
    return ae_net
