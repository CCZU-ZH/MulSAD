import torch.nn as nn

class CNN_Encoder(nn.Module):
    def __init__(self):
        super(CNN_Encoder, self).__init__()
        # 第一个卷积层
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.relu1 = nn.ReLU()
        self.maxpool1 = nn.MaxPool2d(kernel_size=2)
        # 第二个卷积层
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=64, kernel_size=3, stride=1, padding=1)
        self.relu2 = nn.ReLU()
        self.maxpool2 = nn.MaxPool2d(kernel_size=2)
        # 展平层
        self.flatten = nn.Flatten()
        # 第一个全连接层
        self.fc1 = nn.Linear(in_features=64 * 16 * 16, out_features=512)
        self.relu3 = nn.ReLU()
        # 第二个全连接层
        self.fc2 = nn.Linear(in_features=512, out_features=128)

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu1(x)
        x = self.maxpool1(x)
        x = self.conv2(x)
        x = self.relu2(x)
        x = self.maxpool2(x)
        x = self.flatten(x)
        x = self.fc1(x)
        x = self.relu3(x)
        x = self.fc2(x)
        return x


class CNN_Decoder(nn.Module):
    def __init__(self):
        super(CNN_Decoder, self).__init__()
        # 第一个全连接层
        self.fc1 = nn.Linear(in_features=128, out_features=512)
        self.relu1 = nn.ReLU()
        # 第二个全连接层
        self.fc2 = nn.Linear(in_features=512, out_features=64 * 16 * 16)
        self.relu2 = nn.ReLU()
        # 重塑层
        self.reshape = nn.Unflatten(dim=1, unflattened_size=(64, 16, 16))
        # 第一个转置卷积层
        self.trans_conv1 = nn.ConvTranspose2d(in_channels=64, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.relu3 = nn.ReLU()
        self.upsample1 = nn.Upsample(scale_factor=2)
        # 第二个转置卷积层
        self.trans_conv2 = nn.ConvTranspose2d(in_channels=32, out_channels=1, kernel_size=3, stride=1, padding=1)
        self.upsample2 = nn.Upsample(scale_factor=2)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu1(x)
        x = self.fc2(x)
        x = self.relu2(x)
        x = self.reshape(x)
        x = self.trans_conv1(x)
        x = self.relu3(x)
        x = self.upsample1(x)
        x = self.trans_conv2(x)
        x = self.upsample2(x)
        return x


class CNN_Autoencoder(nn.Module):
    def __init__(self):
        super(CNN_Autoencoder, self).__init__()
        self.encoder = CNN_Encoder()
        self.decoder = CNN_Decoder()

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded

