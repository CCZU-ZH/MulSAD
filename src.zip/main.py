import click
import torch
import logging
import random
import numpy as np

from src.utils.config import Config
from src.BISAD import BISAD
from src.datasets.main import load_dataset

def main():
    """
    Deep SAD, a method for deep semi-supervised anomaly detection.
    :arg DATASET_NAME: Name of the dataset to load.
    :arg NET_NAME: Name of the neural network to use.
    :arg XP_PATH: Export path for logging the experiment.
    :arg DATA_PATH: Root path of data.
    """
    # Get configuration
    cfg = Config()
    # 获取配置中的各个参数
    dataset_name = cfg.settings['dataset_name']
    net_name = cfg.settings['net_name']
    xp_path = cfg.settings['xp_path']
    data_path = cfg.settings['data_path']
    load_model = cfg.settings['load_model']
    ratio_known_normal = cfg.settings['ratio_known_normal']
    ratio_known_outlier = cfg.settings['ratio_known_outlier']
    ratio_pollution = cfg.settings['ratio_pollution']
    device = cfg.settings['device']
    pretrain = cfg.settings['pretrain']
    num_threads = cfg.settings['num_threads']
    n_jobs_dataloader = cfg.settings['n_jobs_dataloader']
    normal_class = cfg.settings['normal_class']
    known_outlier_class = cfg.settings['known_outlier_class']
    n_known_outlier_classes = cfg.settings['n_known_outlier_classes']

    # 从 JSON 文件加载配置（如果需要）
    if cfg.settings['load_config']:
        cfg.load_config(cfg.settings['load_config'])
    # Set seed
    if cfg.settings['seed'] != -1:
        random.seed(cfg.settings['seed'])
        np.random.seed(cfg.settings['seed'])
        torch.manual_seed(cfg.settings['seed'])
        torch.cuda.manual_seed(cfg.settings['seed'])
        torch.backends.cudnn.deterministic = True


    # Default device to 'cpu' if cuda is not available
    if not torch.cuda.is_available():
        device = 'cpu'
    # Set the number of threads used for parallelizing CPU operations
    if num_threads > 0:
        torch.set_num_threads(num_threads)
    # Load data
    dataset = load_dataset(dataset_name, data_path, normal_class, known_outlier_class)
    # Initialize DeepSAD model and set neural network phi
    bisad = BISAD(cfg.settings['eta'])
    bisad.set_network()
   #############################################################

    # If specified, load Deep SAD model (center c, network weights, and possibly autoencoder weights)
    if load_model:
        bisad.load_model(model_path=load_model, load_ae=True, map_location=device)

    if pretrain:
        # Pretrain model on dataset (via autoencoder)
        bisad.pretrain(dataset,
                         optimizer_name=cfg.settings['ae_optimizer_name'],
                         lr=cfg.settings['ae_lr'],
                         n_epochs=cfg.settings['ae_n_epochs'],
                         lr_milestones=cfg.settings['ae_lr_milestone'],
                         batch_size=cfg.settings['ae_batch_size'],
                         weight_decay=cfg.settings['ae_weight_decay'],
                         device=device,
                         n_jobs_dataloader=n_jobs_dataloader)

        # Save pretraining results
        bisad.save_ae_results(export_json=xp_path + '/ae_results.json')
    ####################################################
    # Log training details

    # Train model on dataset
    bisad.train(dataset,
                  optimizer_name=cfg.settings['optimizer_name'],
                  lr=cfg.settings['lr'],
                  n_epochs=cfg.settings['n_epochs'],
                  lr_milestones=cfg.settings['lr_milestone'],
                  batch_size=cfg.settings['batch_size'],
                  weight_decay=cfg.settings['weight_decay'],
                  device=device,
                  n_jobs_dataloader=n_jobs_dataloader)

    # Test model
    bisad.test(dataset, device=device, n_jobs_dataloader=n_jobs_dataloader)

    # Save results, model, and configuration
    bisad.save_results(export_json=xp_path + '/results.json')
    bisad.save_model(export_model=xp_path + '/model.tar')
    cfg.save_config(export_json=xp_path + '/config.json')

if __name__ == '__main__':
    main()
