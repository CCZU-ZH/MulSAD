# 导入 Config 类
from src.utils.config import Config

def main():
    # 创建Config实例
    config = Config()

    # # 加载外部配置文件
    # config.load_config('path/to/your/config.json')

    # 打印加载的配置
    print(config.settings)
    #
    # # 保存配置到文件
    # config.save_config('path/to/save/config.json')
    #
    # # 更新配置后直接保存
    # new_settings = {
    #     'lr': 0.005,
    #     'batch_size': 64
    # }
    # config = Config(new_settings)
    #  config.save_config('path/to/save/new_config.json')
    learning_rate = config.settings.get('weight_decay', 0.01)  # 如果没有 'weight_decay'，默认为 0.01
    print(learning_rate)

if __name__ == "__main__":
    main()