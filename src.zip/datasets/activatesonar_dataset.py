import os
import torch
from PIL import Image
from torch.utils.data import Dataset, random_split, DataLoader
from torchvision.transforms import Compose, Resize, ToTensor

class CustomImageDataset(Dataset):
    def __init__(self, root_dir, normal_class, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.normal_class = normal_class
        self.classes = [0, 1]  # 假设你的数据集有两个类别：正常和异常
        self.images = []
        self.labels = []

        # 遍历根目录下的所有文件和子目录
        for dirpath, dirnames, filenames in os.walk(self.root_dir):
            for filename in filenames:
                if filename.endswith('.jpg') or filename.endswith('.png'):  # 假设你的图像文件是.jpg 或.png 格式
                    image_path = os.path.join(dirpath, filename)
                    label = 0 if self._get_class(filename) == self.normal_class else 1
                    self.images.append(image_path)
                    self.labels.append(label)

    def _get_class(self, filename):
        # 从文件名中提取类别信息
        # 这里假设文件名的格式为 "class_name_xxx.jpg" 或 "class_name_xxx.png"
        return filename.split('_')[0]

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        image_path = self.images[idx]
        label = self.labels[idx]
        image = Image.open(image_path).convert('RGB')

        if self.transform:
            image = self.transform(image)

        return image, label

    def get_train_test_split(self, test_size=0.1, random_state=None):
        # 计算训练集和测试集的大小
        dataset_size = len(self)
        test_size = int(test_size * dataset_size)
        train_size = dataset_size - test_size

        # 如果 random_state 不是 None，则创建一个 torch.Generator 对象
        if random_state is not None:
            generator = torch.Generator().manual_seed(random_state)
        else:
            generator = None

        # 使用正确的 generator 对象进行随机分割
        return random_split(self, [train_size, test_size], generator=generator)

    def loaders(self, batch_size: int, shuffle_train=True, shuffle_test=False, num_workers: int = 0):
        """
        创建并返回训练集和测试集的数据加载器。

        :param batch_size: 每个批次的样本数量
        :param shuffle_train: 是否打乱训练集数据，默认为 True
        :param shuffle_test: 是否打乱测试集数据，默认为 False
        :param num_workers: 数据加载时使用的线程数，默认为 0
        :return: 训练集数据加载器和测试集数据加载器
        """
        train_dataset, test_dataset = self.get_train_test_split(test_size=0.1, random_state=42)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle_train, num_workers=num_workers)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=shuffle_test, num_workers=num_workers)
        return train_loader, test_loader

# 定义图像变换
transform = Compose([
    Resize((64, 64)),
    ToTensor()
])

# 创建数据集实例
dataset = CustomImageDataset(root_dir='data', normal_class='notarget', transform=transform)

# 获取训练集和测试集的数据加载器
train_loader, test_loader = dataset.loaders(batch_size=32, shuffle_train=True, shuffle_test=False, num_workers=2)